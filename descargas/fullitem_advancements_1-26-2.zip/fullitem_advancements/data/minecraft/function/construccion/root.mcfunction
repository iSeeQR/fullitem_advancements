tellraw @p {"color":"dark_aqua","text":"Logros por obtener todos los items de Minecraft, activados."}
execute as @p run scoreboard objectives add Advancements dummy

execute as @p run scoreboard objectives setdisplay list Advancements
 execute as @p run scoreboard players add @p Advancements 1666
scoreboard players add @p Advancements 0