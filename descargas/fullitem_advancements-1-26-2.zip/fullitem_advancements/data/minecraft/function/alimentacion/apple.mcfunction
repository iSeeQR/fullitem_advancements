scoreboard players remove @p Advancements 1 
execute as @p[scores={Advancements=1695}] run tellraw @p {"color":"light_purple","text":"Quedan 1695 items. "} 
execute as @p[scores={Advancements=1695}] run tellraw @p {"color":"dark_aqua","text":"Para ver conteo pulsar 'TAB'. Para ver logros pulsar 'L' "} 
execute as @p[scores={Advancements=10}] run tellraw @p {"color":"light_purple","text":"Quedan 10 items."} 
execute as @p[scores={Advancements=5}] run tellraw @p {"color":"light_purple","text":"Quedan 5 items."} 
execute as @p[scores={Advancements=3}] run tellraw @p {"color":"light_purple","text":"Quedan tres items."} 
execute as @p[scores={Advancements=2}] run tellraw @p {"color":"light_purple","text":"Quedan dos items."} 
execute as @p[scores={Advancements=1}] run tellraw @p {"color":"light_purple","text":"Queda un item."} 
execute as @p[scores={Advancements=0}] run tellraw @p {"color":"dark_aqua","text":"Has conseguido todos los items de Minecraft."} 
execute as @p[scores={Advancements=0}] run tellraw @p {"color":"red"      ,"text":"Enhorabuena!"} 
execute as @p[scores={Advancements=0}] run tellraw @p {"color":"dark_aqua","text":"Se ha generado un cofre en encima de ti."} 
execute as @p[scores={Advancements=0}] run setblock ~ ~1 ~ chest{Items:[{Slot:0,id:glow_lichen,Count:1},{Slot:1,id:leather_helmet,Count:1,tag:{display:{color:15859711}}},{Slot:2,id:glow_lichen,Count:1},{Slot:3,id:glow_lichen,Count:1},{Slot:4,id:glow_lichen,Count:1},{Slot:5,id:glow_lichen,Count:1},{Slot:6,id:glow_lichen,Count:1},{Slot:7,id:glow_lichen,Count:1},{Slot:8,id:glow_lichen,Count:1},{Slot:9,id:leather_leggings,Count:1,tag:{display:{color:15859711}}},{Slot:10,id:leather_chestplate,Count:1,tag:{display:{color:15987398}}},{Slot:11,id:leather_horse_armor,Count:1,tag:{display:{color:15859711}}},{Slot:12,id:glow_lichen,Count:1},{Slot:13,id:debug_stick,Count:1},{Slot:14,id:glow_lichen,Count:1},{Slot:15,id:red_tulip,Count:1},{Slot:16,id:emerald,Count:64},{Slot:17,id:white_tulip,Count:1},{Slot:18,id:glow_lichen,Count:1},{Slot:19,id:leather_boots,Count:1,tag:{display:{color:15987398}}},{Slot:20,id:glow_lichen,Count:1},{Slot:21,id:glow_lichen,Count:1},{Slot:22,id:glow_lichen,Count:1},{Slot:23,id:glow_lichen,Count:1},{Slot:24,id:glow_lichen,Count:1},{Slot:25,id:glow_lichen,Count:1},{Slot:26,id:glow_lichen,Count:1}]} replace 
